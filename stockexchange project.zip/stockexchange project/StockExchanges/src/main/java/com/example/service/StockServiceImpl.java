package com.example.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.repository.stockrepo;
import com.example.entity.CompanyShare;



@Service
public class StockServiceImpl implements StockService {
	   @Autowired
	     private stockrepo stockrepository;
		@Override
		public List<CompanyShare> getAllCompanies() {
			return stockrepository.findAll();
		}
		@Override
		public void saveCompany(CompanyShare company) {
			this.stockrepository.save(company);
			
		}
		@Override
		public CompanyShare getStockById(long companyId) {
			Optional<CompanyShare> optional = stockrepository.findById(companyId);
			CompanyShare s = null;
			if (optional.isPresent()) {
				s = optional.get();
			} else {
				throw new RuntimeException(" stock not found for id :: " + companyId);
			}
			return s;
		}
			
		
		@Override
		public void deleteStockById(long companyId) {
			this.stockrepository.deleteById(companyId);
			
		}
		@Override
		public Page<CompanyShare> findPaginated(int pageNo, int pageSize, String sortField, String sortDir) {
			Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending() :
				Sort.by(sortField).descending();
			
			Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
			return this.stockrepository.findAll(pageable);
		}

}
