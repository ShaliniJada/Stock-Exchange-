package com.example.demo.web;




import com.example.demo.repository.stockrepo;

import com.example.entity.CompanyShare;

import lombok.RequiredArgsConstructor;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class CompanyController {

	
	@Autowired
	private stockrepo stockrepository;

	@GetMapping("/companystock")
	public String getAll(Map<String, Iterable<CompanyShare>> map) {
		Iterable<CompanyShare> companystock = stockrepository.findAll();
		map.put("companystock",companystock);
		return "companystock";
	}
	
	 @GetMapping("/delete-stock")
	    public String deleteStock(
	            @RequestParam long CompanyId
	    ) {
	        System.out.println( CompanyId);
	        stockrepository.deleteById( CompanyId);
	        return "redirect:/companystock";
	    }

	    @PostMapping("/new-stock")
	    public String newStock(@RequestParam Map<String,String> requestParams) throws Exception{
	    	String companyName=requestParams.get("companyName");
	    	 String sharePrice=requestParams.get("sharePrice");

	   
	        CompanyShare newStock = new CompanyShare( 1L, companyName,Double.parseDouble(sharePrice));
	        stockrepository.save(newStock);
	        return "redirect:/companystock";
	    }
	
	

}


