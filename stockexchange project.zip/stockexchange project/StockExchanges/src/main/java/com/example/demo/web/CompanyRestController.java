package com.example.demo.web;

import java.util.HashMap;

import java.util.Map;

import org.springframework.web.bind.annotation.RestController;


import com.example.entity.CompanyShare;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class CompanyRestController {
	private static Map<Integer, CompanyShare> companystock = new HashMap<>();

    static {
        companystock.put(1, new CompanyShare(1L, "ABC & Company ", 230.0));
        companystock.put(2, new CompanyShare(2L, "XYZ & Company",500.0 ));
        companystock.put(3, new CompanyShare(3L, "PQR Industrial company ",345.0));
        companystock.put(4, new CompanyShare(4L, "MLN & Company",275.0));
        companystock.put(5, new CompanyShare(5L, "JKL Industry Ltd",247.0));
    }

}
